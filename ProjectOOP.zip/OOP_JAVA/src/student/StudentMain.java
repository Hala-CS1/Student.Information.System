package student;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) {

		Scanner keyboard = new Scanner(System.in); // لإنشاء كائن لإدخال المستخدم
		StudentGraddes s1 = new StudentGraddes(); //H إنشاء كائن الطالب مع الدرجات

		// A تسجيل الدخول
		Login login = new Login();
		if (!login.login()) { // التحقق من اسم المستخدم وكلمة المرور
			System.out.println("Exiting program...");
			return; // إنهاء البرنامج إذا فشل تسجيل الدخول
		}
		System.out.println("Welcome!");

		boolean exit = false; // متغير للتحكم في الحلقة الرئيسية للقائمة

		// الحلقة الرئيسية للقائمة menu-based
		while (!exit) {
			// H عرض الخيارات للمستخدم
			System.out.println("\n... Student Information System Menu ...");
			System.out.println("1. Enter Student Info");
			System.out.println("2. Add Courses & Grades");
			System.out.println("3. Enter Mentor Info");
			System.out.println("4. Display Student Info");
			System.out.println("5. Save to File");
			System.out.println("6. Read File");
			System.out.println("7. Exit");
			System.out.print("Enter your Choice: ");

			int choice = keyboard.nextInt();
			keyboard.nextLine();

			switch (choice) {
			case 1: // H إدخال بيانات الطالب
				System.out.print("Enter Your ID number : ");
				s1.setID(keyboard.nextLine()); // إدخال رقم الهوية

				System.out.print("Enter Your Name: ");
				s1.setName(keyboard.nextLine()); // إدخال الاسم

				// التحقق من صحة التخصص باستخدام do-while
				String major;
				do {
					System.out.print("Enter Student Major (CS, IT, COE, SWE, SYS, AI): ");
					major = keyboard.nextLine().toUpperCase();
				} while (!Arrays.asList("CS", "IT", "COE", "SWE", "SYS", "AI").contains(major));
				s1.setMajor(major); // تعيين التخصص بعد التأكد من صحته
				break;

			case 2: // H إضافة الكورسات والدرجات
				System.out.print("Number of courses: ");
				int numCourses = keyboard.nextInt();
				keyboard.nextLine();

				if (numCourses > 0) { // إذا تم إدخال كورسات
					s1.setGrades(new double[numCourses][]); // تهيئة مصفوفة الدرجات لكل كورس

					for (int i = 0; i < numCourses; i++) { // لكل كورس
						System.out.print("Enter Course " + (i + 1) + ": ");
						s1.addCourse(keyboard.nextLine()); // إضافة اسم الكورس للقائمة

						System.out.print("Number of grades: "); // إدخال عدد الدرجات للكورس
						int numGrades = keyboard.nextInt();
						keyboard.nextLine();

						// تحقق إذا عدد الدرجات سلبي، نطلب إدخال مرة ثانية فقط
						if (numGrades < 0) {
							System.out.println("Invalid number! Number cannot be negative.");
							System.out.print("Number of grades: ");
							numGrades = keyboard.nextInt();
							keyboard.nextLine();
						}

						for (int j = 0; j < numGrades; j++) { // لكل درجة
							System.out.print("Enter Grade " + (j + 1) + ": ");
							double grade = keyboard.nextDouble();
							keyboard.nextLine();
							
							s1.addGrade(i, grade);
						}
					}
				} else {
					System.out.println("No courses entered."); // إذا لم يدخل المستخدم أي كورس
				}
				break;

			case 3: // H إدخال بيانات المشرف
				System.out.print("Enter Mentor Name: ");
				String mName = keyboard.nextLine(); // اسم المشرف

				System.out.print("Enter Mentor Department: ");
				String mDept = keyboard.nextLine(); // قسم المشرف

				s1.setMentor(new Mentor(mName, mDept)); // تعيين المشرف للطالب
				break;

			case 4: // H عرض معلومات الطالب
				System.out.println("\n... Student Info ...");
				System.out.println(s1); // طباعة البيانات الأساسية (ID, Name, Mentor, Major)

				double totalAll = 0;
				if (s1.getGrades() != null) {
					totalAll = s1.sumGrades(s1.getGrades(), 0, 0); //F حساب المجموع الكلي لجميع الدرجات
				}

				System.out.println("\nGrades:");
				for (int i = 0; i < s1.getCourses().size(); i++) {
					if (s1.getGrades()[i] != null && s1.getGrades()[i].length > 0) {
						double courseTotal = 0;
						for (double g : s1.getGrades()[i])
							courseTotal += g;

						// طباعة الدرجات + المجموع الكلي للكورس + Pass/Fail
						System.out.println(s1.getCourses().get(i) + ": " + Arrays.toString(s1.getGrades()[i])
								+ " , Total: " + courseTotal + " : " + (s1.isPass(i) ? "Pass" : "Fail"));
					} else {
						System.out.println(s1.getCourses().get(i) + ": No grades entered yet");
					}
				}
				System.out.println("\nSearch Result for grade 100 : ");
				s1.search100();
				// استخدام الميثود للبحث
				System.out.println("\nTotal Grades (All Courses): " + totalAll); // F المجموع الكلي
				break;

			case 5: // F,L حفظ البيانات في ملف نصي
				try (FileWriter writer = new FileWriter("StudentInfo.txt")) {
					writer.write(s1 + "\n\n");

					for (int i = 0; i < s1.getCourses().size(); i++) {
						if (s1.getGrades()[i] != null) {
							double total = 0;
							for (double g : s1.getGrades()[i])
								total += g;
							writer.write(s1.getCourses().get(i) + " : " + Arrays.toString(s1.getGrades()[i]) + " = "
									+ (s1.isPass(i) ? "Pass" : "Fail") + ", Total: " + total + "\n");
						} else {
							writer.write(s1.getCourses().get(i) + ": No grades entered yet\n");
						}
					}

					// البحث عن 100 مباشرة في Main أثناء حفظ الملف
					double searchGrade = 100;
					System.out.println("\nSearch Result for grade: " + searchGrade);
					writer.write("\nSearch Result for grade: " + searchGrade + "\n");

					for (int i = 0; i < s1.getCourses().size(); i++) {
						if (s1.getGrades()[i] != null) {
							for (double g : s1.getGrades()[i]) {
								if (g == searchGrade) {
									String line = "Grade 100 found in course " + s1.getCourses().get(i) + "\n";
									System.out.print(line);
									writer.write(line);
									break; // لكل كورس مرة واحدة فقط
								}
							}
						}
					}
					writer.write("\nTotal Grades: " + s1.sumGrades(s1.getGrades(), 0, 0) + "\n");

					System.out.println("\nFile saved successfully!");
				} catch (IOException e) {
					System.out.println("Error saving file: " + e.getMessage());
				}
				break;

			case 6: //H قراءة الملف
				try (Scanner fileReader = new Scanner(new File("StudentInfo.txt"))) {
					System.out.println("\n.... File Content ....");
					while (fileReader.hasNextLine()) {
						System.out.println(fileReader.nextLine());
					}
				} catch (IOException e) {
					System.out.println("Cannot read file: " + e.getMessage());
				}
				break;

			case 7: // H الخروج من البرنامج
				exit = true;
				System.out.println("\nExiting Program...");
				break;

			default: // H خيار غير صحيح
				System.out.println("Invalid choice! Please try again.");
			}
		}
	}
}