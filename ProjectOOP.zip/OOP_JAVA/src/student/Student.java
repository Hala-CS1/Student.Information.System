package student;

import java.util.ArrayList;

public class Student {
	private String ID; // Hرقم هوية الطالب
	private String Name; // H اسم الطالب
	private ArrayList<String> Courses; // L قائمة الكورسات
	private Mentor mentor; // H المشرف الأكاديمي

	// Constructor H
	public Student() {
		this.ID = null;
		this.Name = null;
		this.Courses = new ArrayList<>();
		this.mentor = null;
	}

	// Constructor H
	public Student(String ID, String Name, Mentor mentor) {
		this.ID = ID;
		this.Name = Name;
		this.Courses = new ArrayList<>();
		this.mentor = mentor;
	}

	// Setter Getter H
	public void setID(String ID) {
		this.ID = ID;
	}

	public String getID() {
		return ID;
	}

	// Setter Getter H
	public void setName(String Name) {
		this.Name = Name;
	}

	public String getName() {
		return Name;
	}

	// Getter / Setter L
	public ArrayList<String> getCourses() {
		return Courses;
	}

	public void addCourse(String course) {
		this.Courses.add(course);
	}

	// Setter Getter L
	public void setMentor(Mentor mentor) {
		this.mentor = mentor;
	}

	public Mentor getMentor() {
		return mentor;
	}

	// ToString H,L
	@Override
	public String toString() {
		return "ID: " + ID +
			   "\nName: " + Name +
			   "\nCourses: " + Courses +
		       "\nMentor: " + mentor ;}
	
}