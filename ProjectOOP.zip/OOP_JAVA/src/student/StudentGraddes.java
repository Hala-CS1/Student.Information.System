package student;

import java.util.Arrays;

//H تعريف تخصص الطالب
enum Major {
	CS, IT, COE, SWE, SYS, AI
}

public class StudentGraddes extends Student {

	private Major major; // A تخصص الطالب
	private double[][] grades; // A درجات الكورسات (مصفوفة ثنائية الأبعاد)

	// Constructors A
	public StudentGraddes() {
		super();
	}

	// Constructors A
	public StudentGraddes(String ID, String name, Mentor mentor, Major major, double[][] grades) {
		super(ID, name, mentor);
		this.major = major;
		this.grades = grades;
	}

	// Setter / Getter A
	public void setMajor(String major) {
		this.major = Major.valueOf(major);
	}

	public Major getMajor() {
		return major;
	}

	// Setter / Getter A
	public void setGrades(double[][] grades) {
		this.grades = grades;
	}

	public double[][] getGrades() {
		return grades;
	}

	// Method A,H إضافة درجة لكورس محدد
	public void addGrade(int courseIndex, double grade) {
		try {
			if (grade < 0 || grade > 100) {
				System.out.println("Invalid grade! Must be between 0 and 100.");
				return; // الخروج بدون إضافة الدرجة
			}

			double[] courseGrades = grades[courseIndex];
			if (courseGrades == null) {
				grades[courseIndex] = new double[] { grade };
			} else {
				double[] newGrades = new double[courseGrades.length + 1];
				System.arraycopy(courseGrades, 0, newGrades, 0, courseGrades.length);
				newGrades[newGrades.length - 1] = grade;
				grades[courseIndex] = newGrades;
			}

		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Error: Invalid course index!");
		} catch (Exception e) {
			System.out.println("Unexpected error: " + e.getMessage());
		}
	}

	// Method A,H ترتيب درجات الكورس تصاعديًا
	public void sortGrades(int courseIndex) {
		if (grades != null && courseIndex >= 0 && courseIndex < grades.length && grades[courseIndex] != null)
			Arrays.sort(grades[courseIndex]);
	}

	// Method recursion F جمع جميع الدرجات باستخدام
	public double sumGrades(double[][] arr, int row, int col) {
		if (row >= arr.length)
			return 0; // شرط التوقف

		if (arr[row] == null || col >= arr[row].length)
			return sumGrades(arr, row + 1, 0); // الانتقال للصف التالي

		return arr[row][col] + sumGrades(arr, row, col + 1);
	}

	// Method F,H التحقق إذا الكورس ناجح أو راسب
	public boolean isPass(int courseIndex) {
		if (grades == null || courseIndex < 0 || courseIndex >= grades.length || grades[courseIndex] == null)
			return false;

		double sum = 0;
		for (double g : grades[courseIndex])
			sum += g;

		// إذا مجموع درجات الكورس اكبر او يساوي 60 = Pass
		return sum >= 60;
	}

	//F تبحث عن درجة 100
	public void search100() {
		for (int i = 0; i < getCourses().size(); i++) {
			if (grades[i] != null) {
				for (double g : grades[i]) {
					if (g == 100) {
						System.out.println("Grade 100 found in course " + getCourses().get(i));
						break; // يكفي طباعة مرة واحدة لكل كورس
					}
				}
			}
		}
	}

	// ToString H
	@Override
	public String toString() {
		String result = super.toString();
		result += "\nMajor: " + major;
		return result;
	}

}